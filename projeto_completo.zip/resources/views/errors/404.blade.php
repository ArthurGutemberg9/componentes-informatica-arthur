<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Não Encontrada - TechStore</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <!-- Navegação -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center space-x-2">
                    <i class="fas fa-microchip text-purple-600 text-2xl"></i>
                    <a href="{{ route('home') }}" class="text-2xl font-bold text-gray-900 hover:text-purple-600 transition">TechStore</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Conteúdo Principal -->
    <div class="min-h-screen flex items-center justify-center px-4">
        <div class="text-center max-w-md">
            <!-- Ícone de Erro -->
            <div class="mb-8">
                <i class="fas fa-exclamation-triangle text-8xl text-yellow-500 mb-4"></i>
            </div>

            <!-- Código de Erro -->
            <h1 class="text-6xl font-bold text-gray-900 mb-4">404</h1>

            <!-- Título -->
            <h2 class="text-3xl font-bold text-gray-900 mb-4">Página Não Encontrada</h2>

            <!-- Descrição -->
            <p class="text-lg text-gray-600 mb-8">
                Desculpe! A página que você está procurando não existe ou foi movida. Verifique a URL e tente novamente.
            </p>

            <!-- Botões de Ação -->
            <div class="flex flex-col space-y-4">
                <a href="{{ route('home') }}" class="bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition font-bold text-lg">
                    <i class="fas fa-home mr-2"></i>Ir para Página Inicial
                </a>
                <a href="{{ route('componentes.index') }}" class="bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition font-bold text-lg">
                    <i class="fas fa-list mr-2"></i>Ver Catálogo
                </a>
            </div>

            <!-- Sugestão -->
            <div class="mt-12 p-6 bg-blue-50 rounded-lg border border-blue-200">
                <p class="text-sm text-blue-700">
                    <i class="fas fa-lightbulb mr-2"></i>
                    <strong>Dica:</strong> Use a navegação acima para encontrar o que procura.
                </p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-8 px-4 mt-12 absolute bottom-0 w-full">
        <div class="max-w-7xl mx-auto text-center text-gray-400">
            <p>&copy; 2026 TechStore. Todos os direitos reservados. | Desenvolvido por Arthur Gutemberg</p>
        </div>
    </footer>
</body>
</html>
